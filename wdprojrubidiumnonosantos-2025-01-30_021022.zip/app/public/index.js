//creates a new browser window for easy level
function myFunction() {
  window.open("easy.html");
}
//creates a new browser window for medium level
function myFunction1() {
  window.open("medium.html");
}
//creates a new browser window for hard level
function myFunction2() {
  window.open("hard.html");
}
